#include "testlib.h"
#include <algorithm>
#include <vector>
#include <unordered_map>
using namespace std;
const int MAX_N = 3004;
typedef long long ll;
ll a[MAX_N], b[MAX_N];
int n;
int t[MAX_N];
vector<pair<int, int>> opts;
unordered_map<ll, vector<int>> poses;
int main(int argc, char *argv[])
{
    registerTestlibCmd(argc, argv);
    n = inf.readInt();
    for (int i = 1; i <= n; i++)
    {
        a[i] = inf.readLong();
        // poses[x]为a中x出现的所有位置
        poses[a[i]].emplace_back(i);
    }
    for (int i = 1; i <= n; i++)
    {
        b[i] = a[i];
    }
    sort(b + 1, b + 1 + n);
    // 找每个x的目标位
    for (const auto &p : poses)
    {
        for (int i = 1; i <= n; i++)
        {
            if (b[i] == p.first)
            {
                for (int j = i; j <= n && b[i] == b[j]; j++)
                {
                    // 得到目标位
                    t[p.second[j - i]] = j;
                }
                break;
            }
        }
    }
    int res = 0;
    for (int i = 1; i <= n; i++)
    {
        res += abs(t[i] - i);
    }
    res >>= 1;

    int v = ouf.readInt();
    if (v != res)
    {
        quitf(_wa, "v");
        return 0;
    }
    int m = ouf.readInt();
    for (int i = 1; i <= m; i++)
    {
        int x = ouf.readInt();
        int y = ouf.readInt();
        v -= abs(x - y);
        swap(a[x], a[y]);
    }
    if (v != 0)
    {
        quitf(_wa, "trick");
        return 0;
    }
    for (int i = 1; i <= n; i++)
    {
        if (a[i] != b[i])
        {
            quitf(_wa, "t");
            return 0;
        }
    }
    quitf(_ok, "ac");
    return 0;
}