/*
 * @Description:
 * @Version: 1.0
 * @Autor: i_mailang
 * @Date: 2022-05-22 15:56:40
 * @LastEditors: i_mailang
 * @LastEditTime: 2022-05-22 22:59:25
 */
#include "testlib.h"
typedef long long ll;
const ll mod = 998244353;
int n;
ll qp(ll x, ll y)
{
    ll res = 1;
    while (y)
    {
        if (y & 1)
            res = res * x % mod;
        x = x * x % mod;
        y >>= 1;
    }
    return res;
}

bool vis[1 << 5 + 5][1 << 5 + 5][1 << 5 + 5];
int main(int argc, char *argv[])
{
    registerTestlibCmd(argc, argv);
    int m = inf.readInt();
    ll stdans = ((2 * ((((qp(2, m) * qp(2, m)) % mod) * qp(2, m)) % mod + mod - 1) % mod) % mod - 1 + mod) % mod;
    ll outans = ouf.readInt();
    if (stdans != outans)
    {
        quitf(_wa, "wrong answer");
        return 0;
    }
    else
    {
        if (m <= 5)
        {
            int as = 0;
            ouf.readEoln();
            int n = 1 << m;
            vis[1][1][1] = true;
            int x = 1, y = 1, z = 1;
            bool loop = true;
            char la = 0;
            while (loop)
            {
                char ch = ouf.readChar();
                switch (ch)
                {
                case 'U':
                    y++;
                    break;
                case 'D':
                    y--;
                    break;
                case 'L':
                    x--;
                    break;
                case 'R':
                    x++;
                    break;
                case 'B':
                    z++;
                    break;
                case 'A':
                    z--;
                    break;
                default:
                    loop = false;
                    break;
                }
                if (!loop)
                    break;
                if (x < 1 || x > n || y < 1 || y > n || z < 1 || z > n || vis[y][x][z])
                {
                    quitf(_wa, "wrong answer");
                    return 0;
                }
                vis[y][x][z] = true;
                if (ch != la)
                {
                    la = ch;
                    as++;
                }
            }
            if (x != n || y != 1 || z != 1)
            {
                quitf(_wa, "wrong answer");
                return 0;
            }
            if (as * 2 - 1 != stdans)
            {
                quitf(_wa, "wrong answer");
                return 0;
            }
        }
        ouf.eoln();
        if (!ouf.eof())
        {
            quitf(_wa, "wrong answer");
            return 0;
        }
    }
    quitf(_ok, "accept");
    return 0;
}