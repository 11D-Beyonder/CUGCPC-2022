/*
 * @Description:
 * @Version: 1.0
 * @Autor: i_mailang
 * @Date: 2022-05-22 15:56:40
 * @LastEditors: i_mailang
 * @LastEditTime: 2022-05-22 16:50:03
 */
#include "testlib.h"
typedef long long ll;
const ll mod = 998244353;
int n;
ll qp(ll x, ll y)
{
    ll res = 1;
    while (y)
    {
        if (y & 1)
            res = res * x % mod;
        x = x * x % mod;
        y >>= 1;
    }
    return res;
}
void func()
{
    for (int i = 0; i < n - 4; i += 2)
    {
        printf("RULU");
    }
    printf("RULUURDRURDDLDR");
    for (int i = n - 4; i > 0; i -= 2)
    {
        printf("DLDR");
    }
}
bool vis[1 << 10 + 5][1 << 10 + 5];
int main(int argc, char *argv[])
{
    registerTestlibCmd(argc, argv);
    int m = inf.readInt();
    ll stdans = ((2 * (qp(2, m) * ((qp(2, m) - 1 + mod) % mod) % mod)) % mod + 1) % mod;
    ll outans = ouf.readInt();
    if (stdans != outans)
    {
        quitf(_wa, "wrong answer");
        return 0;
    }
    else
    {
        if (m <= 10)
        {
            int as = 0;
            ouf.readEoln();
            int n = 1 << m;
            vis[1][1] = true;
            int x = 1, y = 1;
            bool loop = true;
            char la = 0;
            while (loop)
            {
                char ch = ouf.readChar();
                switch (ch)
                {
                case 'U':
                    y++;
                    break;
                case 'D':
                    y--;
                    break;
                case 'L':
                    x--;
                    break;
                case 'R':
                    x++;
                    break;
                default:
                    loop = false;
                    break;
                }
                if (!loop)
                    break;
                if (x < 1 || x > n || y < 1 || y > n || vis[y][x])
                {
                    quitf(_wa, "wrong answer");
                    return 0;
                }
                vis[y][x] = true;
                if (ch != la)
                {
                    la = ch;
                    as++;
                }
            }
            if (x != n || y != 1)
            {
                quitf(_wa, "wrong answer");
                return 0;
            }
            if (as * 2 - 1 != stdans)
            {
                quitf(_wa, "wrong answer");
                return 0;
            }
        }
        ouf.eoln();
        if (!ouf.eof())
        {
            quitf(_wa, "wrong answer");
            return 0;
        }
    }
    quitf(_ok, "accept");
    return 0;
}